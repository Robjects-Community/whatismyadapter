<?php
declare(strict_types=1);

namespace App\Test\TestCase\Command;

use App\Command\ImportProductsCommand;
use Cake\Console\TestSuite\ConsoleIntegrationTestTrait;
use Cake\TestSuite\TestCase;

/**
 * App\Command\ImportProductsCommand Test Case
 *
 * @link \App\Command\ImportProductsCommand
 */
class ImportProductsCommandTest extends TestCase
{
    use ConsoleIntegrationTestTrait;

    /**
     * Test defaultName method
     *
     * @return void
     * @link \App\Command\ImportProductsCommand::defaultName()
     */
    public function testDefaultName(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test getDescription method
     *
     * @return void
     * @link \App\Command\ImportProductsCommand::getDescription()
     */
    public function testGetDescription(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test buildOptionParser method
     *
     * @return void
     * @link \App\Command\ImportProductsCommand::buildOptionParser()
     */
    public function testBuildOptionParser(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }

    /**
     * Test execute method
     *
     * @return void
     * @link \App\Command\ImportProductsCommand::execute()
     */
    public function testExecute(): void
    {
        $this->markTestIncomplete('Not implemented yet.');
    }
}
