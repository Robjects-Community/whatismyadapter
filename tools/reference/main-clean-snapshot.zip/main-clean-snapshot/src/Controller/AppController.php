<?php
declare(strict_types=1);

namespace App\Controller;

use App\Service\ConsentService;
use App\Utility\I18nManager;
use Cake\Controller\Controller;
use Cake\Core\Configure;
use Cake\Event\EventInterface;
use Cake\Log\LogTrait;
// No explicit `use Cake\Http\Response;` needed just for redirecting in beforeFilter

class AppController extends Controller
{
    use LogTrait;

    /**
     * Store a cache key available for all controllers to use
     * Created in the initialize method
     *
     * @var string
     */
    public string $cacheKey;

    /**
     * ConsentService for handling cookie consent and session management
     *
     * @var \App\Service\ConsentService
     */
    protected ConsentService $consentService;

    /**
     * Checks if the current request is an admin request.
     *
     * This method determines whether the request is intended for the admin section
     * of the application by checking if the 'prefix' routing parameter is set to 'Admin'.
     *
     * @return bool Returns true if the request is for the admin section, false otherwise.
     */
    private function isAdminRequest(): bool
    {
        return $this->request->getParam('prefix') === 'Admin';
    }

    /**
     * Initialization hook method.
     *
     * Use this method to add common initialization code like loading components.
     *
     * e.g. `$this->loadComponent('FormProtection');`
     *
     * @return void
     */
    public function initialize(): void
    {
        parent::initialize();
        $this->cacheKey = hash('xxh3', json_encode($this->request->getAttribute('params')));
        $this->loadComponent('Flash');
        $this->loadComponent('Authentication.Authentication'); // Loads the component
        $this->loadComponent('Authorization.Authorization'); // Loads the authorization component

        // Initialize ConsentService
        $this->consentService = new ConsentService();

        // Only load FrontEndSite component for non-admin routes
        if (!$this->request->getParam('prefix') || $this->request->getParam('prefix') !== 'Admin') {
            $this->loadComponent('DefaultTheme.FrontEndSite');
        }
    }

    /**
     * beforeFilter callback.
     *
     * Executed before each controller action. Checks for admin access rights
     * when accessing admin-prefixed routes.
     *
     * @param \Cake\Event\EventInterface $event The event instance.
     * @return void
     */
    public function beforeFilter(EventInterface $event): void
    {
        parent::beforeFilter($event); // Call parent's beforeFilter

        // Skip authorization for both admin and non-admin routes for now
        // TODO: Implement proper authorization policies for admin routes
        $this->Authorization->skipAuthorization();

        I18nManager::setLocaleForLanguage($this->request->getParam('lang', 'en'));

        $identity = null;
        // The AuthenticationComponent (loaded in initialize) makes the identity available.
        // It relies on the AuthenticationMiddleware having run first to populate the request attribute.
        if ($this->components()->has('Authentication')) {
            $identity = $this->Authentication->getIdentity();
        }

        if ($identity) {
            $profilePic = $identity->image_url;

            // Only set profilePic if the user has an actual image file
            if ($profilePic && $identity->image) {
                $this->set(compact('profilePic'));
            }
        }

        if ($this->isAdminRequest()) {
            // Check if user has permission to access admin area
            if (!$identity || !$identity->getIdentifier()) {
                $this->Flash->error(__('Access denied. You must be logged in to view this page.'));
                $event->setResult($this->redirect(['_name' => 'home', 'prefix' => false]));
                return;
            }
            
            // Check if user's role can access admin
            if (!$identity->canAccessAdmin()) {
                $this->Flash->error(__('Access denied. Your role does not have permission to access the admin area.'));
                $event->setResult($this->redirect(['_name' => 'home', 'prefix' => false]));
                return;
            }

            I18nManager::setLocalForAdminArea();
        }

        // Handle consent data processing
        $consentData = $this->consentService->getConsentData($this->request);
        $this->set($consentData);

        // Track last visited page for cookie consent redirection
        $this->trackLastVisitedPage();

        $this->set('activeCtl', $this->request->getParam('controller'));
        $this->set('activeAct', $this->request->getParam('action'));
    }

    /**
     * beforeRender method
     *
     * This method is called before the controller action is rendered. It
     * sets the theme for the view based on the prefix of the request.
     *
     * @param \Cake\Event\EventInterface $event The event object.
     * @return void
     */
    public function beforeRender(EventInterface $event): void
    {
        parent::beforeRender($event);

        $theme = $this->request->getParam('prefix') === 'Admin'
            ? Configure::read('Theme.admin_theme', 'AdminTheme')
            : Configure::read('Theme.default_theme', 'DefaultTheme');

        $this->viewBuilder()->setTheme($theme);
    }

    /**
     * Track the last visited page for cookie consent redirection
     *
     * @return void
     */
    private function trackLastVisitedPage(): void
    {
        // Only track GET requests to avoid tracking form submissions
        if (!$this->request->is('get')) {
            return;
        }

        // Don't track cookie consent pages, admin pages, AJAX requests, or error pages
        $controller = $this->request->getParam('controller');
        $action = $this->request->getParam('action');
        $isAdmin = $this->request->getParam('prefix') === 'Admin';
        $isAjax = $this->request->is('ajax');
        
        if ($isAdmin || $isAjax || 
            ($controller === 'CookieConsents') ||
            ($controller === 'Users' && in_array($action, ['login', 'logout'])) ||
            ($controller === 'Error')) {
            return;
        }

        // Store the current URL in session
        $session = $this->request->getSession();
        if ($session->started()) {
            $currentUrl = $this->request->getRequestTarget();
            $session->write('lastVisitedPage', $currentUrl);
        }
    }
}
